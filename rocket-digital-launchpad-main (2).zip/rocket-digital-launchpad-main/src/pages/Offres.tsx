import { motion } from "framer-motion";
import { Globe, ShoppingCart, LayoutDashboard, FileText, Check, ArrowLeft, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const offers = [
  {
    icon: Globe,
    name: "Site Vitrine",
    description:
      "Un site élégant pour présenter votre entreprise, vos services et vos coordonnées. Idéal pour les PME, artisans et freelances qui veulent une présence en ligne professionnelle.",
    price: "50 000",
    oldPrice: "75 000",
    features: [
      "Design moderne et responsive",
      "Jusqu'à 5 pages",
      "Formulaire de contact",
      "Optimisation SEO de base",
      "Hébergement 1 an inclus",
    ],
    popular: true,
  },
  {
    icon: FileText,
    name: "Landing Page",
    description:
      "Une page unique et percutante conçue pour convertir vos visiteurs en clients. Parfaite pour promouvoir un produit, un événement ou une campagne marketing.",
    price: "30 000",
    oldPrice: "45 000",
    popular: true,
    features: [
      "Design sur mesure",
      "Page unique optimisée",
      "Call-to-action stratégiques",
      "Intégration WhatsApp / réseaux",
      "Livraison rapide (48-72h)",
    ],
  },
  {
    icon: ShoppingCart,
    name: "Site E-commerce",
    description:
      "Une boutique en ligne complète avec catalogue produits, panier d'achat et système de paiement. Vendez vos produits 24h/24 partout en Côte d'Ivoire et au-delà.",
    price: "150 000 - 200 000",
    oldPrice: null,
    popular: true,
    features: [
      "Catalogue produits illimité",
      "Panier & paiement intégré",
      "Gestion des commandes",
      "Design responsive premium",
      "Formation à l'utilisation",
    ],
  },
  {
    icon: LayoutDashboard,
    name: "Application Web Sur Mesure",
    description:
      "Une solution digitale entièrement personnalisée : tableau de bord, système de réservation, gestion interne, plateforme SaaS… Tout est possible.",
    price: "200 000+",
    oldPrice: null,
    features: [
      "Fonctionnalités sur mesure",
      "Base de données dédiée",
      "Authentification utilisateurs",
      "Interface d'administration",
      "Support & maintenance",
    ],
    popular: true,
  },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12 } },
};

const item = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const Offres = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="pt-8 pb-16 text-center relative">
        <div className="container mx-auto px-4">
          <Link to="/">
            <Button variant="ghost" className="absolute left-4 top-8 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour
            </Button>
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="pt-12"
          >
            <h1 className="font-display text-3xl md:text-5xl font-bold mb-4">
              Création de Sites Web à <span className="text-accent">Abidjan</span>
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
              Nos offres de création de sites web en Côte d'Ivoire — des solutions adaptées à chaque besoin et budget.
            </p>
          </motion.div>
        </div>
      </header>

      {/* Cards */}
      <section className="pb-24">
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl"
        >
          {offers.map((offer) => {
            const Icon = offer.icon;
            return (
              <motion.div
                key={offer.name}
                variants={item}
                className={`relative rounded-2xl border p-8 flex flex-col bg-card transition-shadow hover:shadow-xl ${
                  offer.popular ? "border-accent shadow-lg ring-2 ring-accent/20" : "border-border"
                }`}
              >
                {offer.popular && (
                  <span className="absolute -top-3 left-6 bg-accent text-accent-foreground text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wide">
                    Promo lancement
                  </span>
                )}

                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <h2 className="font-display text-xl font-bold">{offer.name}</h2>
                </div>

                <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                  {offer.description}
                </p>

                <div className="mb-6">
                  <div className="flex items-baseline gap-2">
                    <span className="font-display text-3xl font-bold text-foreground">
                      {offer.price} <span className="text-lg">FCFA</span>
                    </span>
                    {offer.oldPrice && (
                      <span className="text-muted-foreground line-through text-sm">
                        {offer.oldPrice} FCFA
                      </span>
                    )}
                  </div>
                </div>

                <ul className="space-y-3 mb-8 flex-1">
                  {offer.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="h-4 w-4 text-accent mt-0.5 shrink-0" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  asChild
                  className={`rounded-full w-full ${
                    offer.popular
                      ? "bg-accent text-accent-foreground hover:bg-accent/90"
                      : "bg-primary text-primary-foreground hover:bg-primary/90"
                  }`}
                >
                  <a
                    href="https://wa.me/2250153760391"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Commander via WhatsApp
                  </a>
                </Button>
              </motion.div>
            );
          })}
        </motion.div>
      </section>

      {/* Payment note */}
      <section className="pb-20">
        <div className="container mx-auto px-4 max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="rounded-2xl border border-accent/30 bg-accent/5 p-6 text-center"
          >
            <p className="font-display font-semibold text-lg mb-2">💰 Modalités de paiement</p>
            <p className="text-muted-foreground">
              <strong className="text-foreground">50% d'acompte</strong> pour démarrer le projet,{" "}
              <strong className="text-foreground">50% au déploiement</strong> du site final.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Offres;

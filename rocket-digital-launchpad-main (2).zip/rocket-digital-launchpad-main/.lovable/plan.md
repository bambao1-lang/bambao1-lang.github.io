

# Digital Rocket — Site Web Agence Digitale 🚀

## Vue d'ensemble
Site vitrine moderne et professionnel pour l'agence digitale "Digital Rocket" basée à Abidjan. Design aux couleurs du logo (bleu foncé #1a3a6b et orange #f5921b), responsive, avec animations fluides pour inspirer confiance et convertir les visiteurs.

## Thème & Style
- **Palette** : Bleu foncé (primaire), Orange vif (accent), fond blanc/gris clair
- **Style** : Minimaliste, high-tech, dynamique
- **Typographie** : Police moderne et lisible
- **Animations** : Fade-in au scroll, hover effects sur les cartes et boutons

## Pages & Sections

### 1. Navigation
- Barre de navigation fixe avec le logo Digital Rocket
- Liens vers chaque section (scroll fluide)
- Menu hamburger sur mobile
- Bouton CTA "Demander un devis" dans la navbar

### 2. Section Hero
- Grand titre "Boostez votre visibilité en ligne 🚀" avec animation d'entrée
- Sous-titre explicatif
- Deux boutons : "Demander un devis" (bleu) + "WhatsApp" (vert avec icône)
- Arrière-plan dynamique avec formes géométriques ou gradient

### 3. Section Services (4 cartes)
- **Création de sites web** — avec icône
- **Optimisation SEO local** — avec icône
- **Google Business** — avec icône
- **Intégration WhatsApp** — avec icône
- Cartes avec effet hover (élévation + couleur accent)

### 4. Section Pourquoi nous choisir
- 4 points forts présentés avec icônes et descriptions courtes
- Design moderne, Site rapide, Marché local, Accompagnement
- Mise en page en grille avec animations au scroll

### 5. Section Projets / Portfolio
- Grille de projets avec images placeholder
- Effet hover avec overlay montrant le nom du projet
- Prêt à être rempli avec de vrais projets

### 6. Section Contact
- Formulaire simple (Nom, Email, Message) avec validation
- Informations de contact : localisation Abidjan, numéro WhatsApp
- Bouton WhatsApp cliquable (+225 0153760391)
- Lien direct vers WhatsApp via l'API wa.me

### 7. Footer
- Logo, liens rapides, réseaux sociaux
- Copyright Digital Rocket

## Responsive
- Layout adaptatif mobile/tablette/desktop
- Navigation hamburger sur mobile
- Grilles qui passent en colonne sur petits écrans

